﻿using BookInventoryAPI.Models;

namespace BookInventoryAPI.Repository
{
    public interface IBook
    {
        /// <summary>
        /// Returns a list of all books in the database
        /// </summary>
        /// <returns></returns>
        List<Book> GetAllBooks();
        /// <summary>
        /// Updates a book to checkedIn = true
        /// </summary>
        /// <returns></returns>
        Task<Book> CheckInBook(int id);
        /// <summary>
        /// Updates a book to checkedIn = false
        /// </summary>
        /// <returns></returns>
        Task<Book> CheckOutBook(int id);
    }
}
