﻿using BookInventoryAPI.Models;
using BookInventoryAPI.Repository;

namespace BookInventoryAPI.DAL
{
    public class BookDAL : IBook
    {
        //context for the database connection
        private readonly BookContext context;

        private readonly IConfiguration _config;

        public BookDAL(BookContext Context, IConfiguration config)
        {
            context = Context;
            _config = config;
        }

        #region Get All Books Method
        /// <summary>
        /// Method that retrieves all books in the database
        /// </summary>
        /// <returns></returns>
        public List<Book> GetAllBooks()
        {
            List<Book> bookList = new List<Book>();

            try
            {
                //query the database to get all of the books
                var books = context.Books.ToList();

                foreach (var book in books)
                {
                    bookList.Add(new Book()
                    {
                        Id = book.Id,
                        Title = book.Title,
                        Author = book.Author,
                        CheckedIn = book.CheckedIn

                    });
                }

                if (bookList.Count == 0)
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("GetAllUsers --- " + ex.Message);
                throw;
            }

            return bookList;
        }

        #endregion
        #region Check in book method 
        public async Task<Book> CheckInBook(int id)

        {
            Book response = new Book();
            try
            {
                //directly access the database and save the update to the CheckedIn status 
                using (var db = new BookContext(_config))
                {
                    var result = db.Books.SingleOrDefault(b => b.Id == id);
                    if (result != null)
                    {
                        result.CheckedIn = true;
                        response = result;
                        db.SaveChanges();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Checkbookin repos" + e.Message);
            }

            return response;
        }

        #endregion
        #region Check out book method 
        //same as above but for checking out 
        public async Task<Book> CheckOutBook(int id)
        {

            Book response = new Book();
            try
            {
                using (var db = new BookContext(_config))
                {
                    var result = db.Books.SingleOrDefault(b => b.Id == id);
                    if (result != null)
                    {
                        result.CheckedIn = false;
                        response = result;
                        db.SaveChanges();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Checkbookout repos" + e.Message);
            }

            return response;

        }
        #endregion
    }
 
}
