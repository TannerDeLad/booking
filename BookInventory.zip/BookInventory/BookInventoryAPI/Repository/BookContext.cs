﻿using BookInventoryAPI.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;


namespace BookInventoryAPI.DAL
{
    public class BookContext : DbContext
    {
        private readonly IConfiguration _config;

        

        public BookContext(IConfiguration config)
        {
            _config = config;

        }

        public BookContext(DbContextOptions<BookContext> options, IConfiguration config)
            : base(options)
        {
            _config = config;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                var databaseConnectionString = _config["BookInventory:DatabaseConnectionString"];
                optionsBuilder.UseSqlServer(databaseConnectionString);

            }
        }

        public DbSet<Book> Books { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Book>().ToTable("MidtermBooks");

        }
    }
}
