using BookInventoryAPI.DAL;
using BookInventoryAPI.Models;
using BookInventoryAPI.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace BookInventoryAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AllowAnonymous]
    public class BookController : ControllerBase
    {
        //context for the database connection
        private readonly BookContext context;

        //variable for holding the configuration data for login authentication
        private IConfiguration config;

        // private readonly IBook repository;
        private readonly IBook repository;

        // constructor for the class
        public BookController(IConfiguration Config)
        {
            config = Config;
            context = new BookContext(config);
            repository = new BookDAL(context, config);
        }


        [HttpGet("GetAllBooks", Name = "GetAllBooks")]
        [AllowAnonymous]
        public async Task<GetBooksResponseModel> GetAllBooks()
        {
            GetBooksResponseModel response = new GetBooksResponseModel();

            //set up a list to hold the incoming books we will get from the db
            List<Book> bookList = new List<Book>();

            try
            {
                bookList = repository.GetAllBooks();

                //check the list isn't empty
                if (bookList.Count != 0)
                {
                    response.Status = true;
                    response.StatusCode = 200;
                    response.bookList = bookList;
                }
                else
                {
                    //there has been an error
                    response.Status = false;
                    response.Message = "Get Failed";
                    response.StatusCode = 0;
                }

            }
            catch (Exception ex)
            {
                response.Status = false;
                response.Message = "Get Failed";
                response.StatusCode = 0;
                //there has been an error
                Console.WriteLine(ex.Message);
            }

            return response;
        }
        //method for checking in a book 
        [HttpPost("CheckInBook", Name = "CheckInBook")]
        [AllowAnonymous]
        public async Task<Book> CheckInBook(Book sent, int maybe = 0) // included the int maybe purely for the ability to test 
            //the method within the api swagger page 
        {
            Book response = new Book();
            if (maybe == 0)
            {
                try
                {
                    //create a new list and save the books from the repository into this list to be locally used inside of this method 
                    List<Book> booklist = new List<Book>();
                    booklist = repository.GetAllBooks();
                    var abook = await repository.CheckInBook(sent.Id).ConfigureAwait(true);
                    //iterate over the list of books and return the checkin value to true for the response object 
                    if (booklist.Count != 0)
                    {
                        foreach (Book book in booklist)
                        {
                            if (book.Id == sent.Id)
                            {
                                Console.WriteLine("Successful Check in");
                                book.CheckedIn = true;
                                response = book;
                            }
                        }
                    }
                    else
                    {
                        //there has been an error
                        Console.WriteLine("The booklist was returned as empty, issue receiving data from the database");
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine("expectional error with " + e.Message);
                }

                return response;
            }
            else
            {
                try
                {
                    //create a new list and save the books from the repository into this list to be locally used inside of this method 
                    List<Book> booklist = new List<Book>();
                    booklist = repository.GetAllBooks();
                    var abook = await repository.CheckInBook(maybe).ConfigureAwait(true);
                    //iterate over the list of books and return the checkin value to true for the response object 
                    if (booklist.Count != 0)
                    {
                        foreach (Book book in booklist)
                        {
                            if (book.Id == maybe)
                            {
                                Console.WriteLine("Successful Check in");
                                book.CheckedIn = true;
                                response = book;
                            }
                        }
                    }
                    else
                    {
                        //there has been an error
                        Console.WriteLine("The booklist was returned as empty, issue receiving data from the database");
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine("expectional error with " + e.Message);
                }

                return response;
            }
        }



        //mimic above code except now it will be toggled to false for the boolean value
        [HttpPost("CheckOutBook", Name = "CheckOutBook")]
        [AllowAnonymous]
        public async Task<Book> CheckOutBook(Book sent, int maybe = 0)
        {
            Book response = new Book();
            if (maybe == 0)
            {
                try
                {
                    //create a new list and save the books from the repository into this list to be locally used inside of this method 
                    List<Book> booklist = new List<Book>();
                    booklist = repository.GetAllBooks();
                    var abook = await repository.CheckInBook(sent.Id).ConfigureAwait(true);
                    //iterate over the list of books and return the checkin value to true for the response object 
                    if (booklist.Count != 0)
                    {
                        foreach (Book book in booklist)
                        {
                            if (book.Id == sent.Id)
                            {
                                Console.WriteLine("Successful Check in");
                                book.CheckedIn = false;
                                response = book;
                            }
                        }
                    }
                    else
                    {
                        //there has been an error
                        Console.WriteLine("The booklist was returned as empty, issue receiving data from the database");
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine("expectional error with " + e.Message);
                }

                return response;
            }
            else
            {
                try
                {
                    //create a new list and save the books from the repository into this list to be locally used inside of this method 
                    List<Book> booklist = new List<Book>();
                    booklist = repository.GetAllBooks();
                    var abook = await repository.CheckInBook(maybe).ConfigureAwait(true);
                    //iterate over the list of books and return the checkin value to true for the response object 
                    if (booklist.Count != 0)
                    {
                        foreach (Book book in booklist)
                        {
                            if (book.Id == maybe)
                            {
                                Console.WriteLine("Successful Check in");
                                book.CheckedIn = false;
                                response = book;
                            }
                        }
                    }
                    else
                    {
                        //there has been an error
                        Console.WriteLine("The booklist was returned as empty, issue receiving data from the database");
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine("expectional error with " + e.Message);
                }

                return response;
            }
        }
    }
}