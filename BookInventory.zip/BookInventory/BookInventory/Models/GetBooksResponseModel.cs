﻿
namespace BookInventory.Models
{
    public class GetBooksResponseModel
    {
        public bool Status { get; set; }
        public int StatusCode { get; set; }
        public string? Message { get; set; }
        public List<Book>? bookList { get; set; }
    }
}
