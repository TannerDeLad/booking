﻿using BookInventory.Models;
using BookInventory.Utility;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;

namespace BookInventory.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            GetBooksResponseModel ResponseModel = null;

            try
            {
                var strSerializedData = string.Empty;
                ServiceHelper objService = new ServiceHelper();
                string response = await objService.GetRequest(strSerializedData, ConstantValues.GetAllBooks, false, string.Empty).ConfigureAwait(true);
                ResponseModel = JsonConvert.DeserializeObject<GetBooksResponseModel>(response);
            }
            catch (Exception ex)
            {
                Console.WriteLine("GetAllBooks API " + ex.Message);
            }
            return View(ResponseModel);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        //this is what the user will be using to see
        public async Task<ActionResult> CheckOutBook(int passed)
        {
            try
            {
                //create the needed models for the data to be saved into
                Book updateme = null;
                GetBooksResponseModel booksmodel = null;
                //initialize the response data string
                var serializedData = string.Empty;
                ServiceHelper service = new ServiceHelper();
                //get all of the book info from the GetAllBooks pathway, ensure this is a 
                //get request here because we are not updating anything in the database with this
                string response = await service.GetRequest(serializedData, ConstantValues.GetAllBooks, false, string.Empty).ConfigureAwait(true);
                //convert it into object format from json so we can use it 
                booksmodel = JsonConvert.DeserializeObject<GetBooksResponseModel>(response);
                //loop through the list we just received
                foreach (Book book in booksmodel.bookList)
                {
                    //Console.WriteLine(book.Id + " " + bookid);
                    if (book.Id == passed)
                    {
                        //below code will update it on the client side. we need the updateme Book object in order to send it to the database. Go ahead and toggle the CheckedIn status too
                        //update the location in the model list with the updated book so that when we reload the page it will work as we want - since the id's start from 1 and index is always less than that we subtract 1 
                        updateme = book;
                        updateme.CheckedIn = false;
                        booksmodel.bookList[book.Id - 1] = updateme;
                        break;
                    }
                }
                //these two lines are what interact with the api and actually update it - we send it the updated book ensure the method on the api side receives Book object
                var sendthis = JsonConvert.SerializeObject(updateme);
                //ensure you use Post Request to update the database and use the correct path
                string response2 = await service.PostRequest(sendthis, ConstantValues.CheckOutBook, false, String.Empty).ConfigureAwait(true);



                //Console.WriteLine("we are not finding the id");
                //return the view with the updated model
                return View("Views/Home/Index.cshtml", booksmodel);
            }
            catch (Exception e)
            {
                Console.WriteLine("we broke checkoutbook initial method - " + e.Message);
            }
            return View();
        }
        //mimicry of above code but now with Checking in a book instead of checking out 
        public async Task<ActionResult> CheckInBook(int passed)
        {
            try
            {
                //create the needed models for the data to be saved into
                Book updateme = null;
                GetBooksResponseModel booksmodel = null;
                //initialize the response data string
                var serializedData = string.Empty;
                ServiceHelper service = new ServiceHelper();
                //get all of the book info from the GetAllBooks pathway, ensure this is a 
                //get request here because we are not updating anything in the database with this
                string response = await service.GetRequest(serializedData, ConstantValues.GetAllBooks, false, string.Empty).ConfigureAwait(true);
                //convert it into object format from json so we can use it 
                booksmodel = JsonConvert.DeserializeObject<GetBooksResponseModel>(response);
                //loop through the list we just received
                foreach (Book book in booksmodel.bookList)
                {
                    //Console.WriteLine(book.Id + " " + bookid);
                    if (book.Id == passed)
                    {
                        //below code will update it on the client side. we need the updateme Book object in order to send it to the database. Go ahead and toggle the CheckedIn status too
                        //update the location in the model list with the updated book so that when we reload the page it will work as we want - since the id's start from 1 and index is always less than that we subtract 1 
                        updateme = book;
                        updateme.CheckedIn = true;
                        booksmodel.bookList[book.Id - 1] = updateme;
                        break;
                    }
                }
                //these two lines are what interact with the api and actually update it - we send it the updated book ensure the method on the api side receives Book object
                var sendthis = JsonConvert.SerializeObject(updateme);
                //ensure you use Post Request to update the database and use the correct path
                string response2 = await service.PostRequest(sendthis, ConstantValues.CheckInBook, false, String.Empty).ConfigureAwait(true);



                //Console.WriteLine("we are not finding the id");
                //return the view with the updated model
                return View("Views/Home/Index.cshtml", booksmodel);
            }
            catch (Exception e)
            {
                Console.WriteLine("we broke checkinbook initial method - " + e.Message);
            }
            return View();
        }
        public async Task<ActionResult> SearchBooks(int searchbox)
        {
            //will need to ensure that the user input a valid number 
            try
            {
                //initalize the needed objects - temp needs to be fully intialized because later on it will need to potentially hold empty values
                GetBooksResponseModel booksmodel = null;
                Book temp = new Book();
                var serializedData = string.Empty;
                ServiceHelper service = new ServiceHelper();
                //getting the list of books
                string response = await service.GetRequest(serializedData, ConstantValues.GetAllBooks, false, string.Empty).ConfigureAwait(true);
                booksmodel = JsonConvert.DeserializeObject<GetBooksResponseModel>(response);
                //iterating through the list of books to see if the user entered a valid id 
                foreach (Book book in booksmodel.bookList)
                {
                    if (book.Id == searchbox)
                    {
                        //when we do find a match we will assign the book into temp, clear the booklist, and only add that book into the booklist and return that to the view 
                        //because we are only returning one book object now instead of the whole list of books 
                        temp = book;
                        booksmodel.bookList.Clear();
                        booksmodel.bookList.Add(temp);
                        break;
                    }
                }
                //if no id is matched error handling 
                if (temp.Author == null)
                {
                    //this if statement fires in the event that no id is matched and now we send the View an empty booklist with a nonsense book object 
                    //to reflect to the user that nothing was returned 
                    ViewBag.Error = "A book with that ID was not found. Please enter a valid ID";
                    temp.Author = "";
                    temp.Title = "";
                    temp.CheckedIn = false;
                    booksmodel.bookList.Clear();
                    booksmodel.bookList.Add(temp);
                    return View("Views/Home/Search.cshtml", booksmodel);
                }
                //if everything is good and chilling send it on overrrr
                else
                {
                    return View("Views/Home/Search.cshtml", booksmodel);
                }
                
            }
            catch (Exception e)
            {
                Console.WriteLine("broke on search books in homecontrol" + e.Message);
            }
            return View();
        }
    }
}