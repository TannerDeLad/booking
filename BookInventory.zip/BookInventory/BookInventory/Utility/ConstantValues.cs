﻿namespace BookInventory.Utility
{
    public class ConstantValues
    {
        public const string GetAllBooks = "Book/GetAllBooks";
        public const string CheckOutBook = "Book/CheckOutBook";
        public const string CheckInBook = "Book/CheckInBook";
    }
}
